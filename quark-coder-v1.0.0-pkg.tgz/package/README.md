# quark-coder ⬡

**One command. Six backends. Three LLM providers. Built-in DASA multi-agent orchestration.**

```bash
npm install -g quark-coder
quark use        # configure backend + LLM provider
quark start      # open AI coding session
quark super "build a REST API with auth"   # full DASA multi-agent pipeline
```

---

## What it does

`quark` unifies every frontier AI coding tool behind one interface. Pick a backend — Bonsai, Claude Code, Gemini CLI, OpenCode, or Z.ai GLM Code. If it's not installed or fails, Quark auto-falls back through the chain, ending at the built-in **Quark Agent** which always works.

For complex tasks, `quark super` runs the full **DASA pipeline**: a Generator analyses the task, composes a specialised agent team, executes each agent with scoped context and tools, then validates output quality through a two-phase Watchdog before writing learnings back to a persistent Agent Pool.

---

## Install

```bash
npm install -g quark-coder
```

Node.js 18+ required.

---

## Quick start

```bash
quark use                                        # configure everything
quark agent "add rate limiting to the API"       # single-agent task
quark super "build JWT auth with refresh tokens" # full multi-agent pipeline
quark start                                      # open external CLI session
```

---

## Backends

Install what you use — Quark falls back automatically.

| Key | Tool | Install |
|-----|------|---------|
| `bonsai` | Bonsai AI | `npm i -g @bonsai-ai/cli` |
| `claude` | Claude Code | `npm i -g @anthropic-ai/claude-code` |
| `gemini` | Gemini CLI | `npm i -g @google/gemini-cli` |
| `opencode` | OpenCode | `npm i -g opencode-ai` |
| `glm` | Z.ai GLM Code | `npm i -g glm-code` |
| `quark-agent` | Built-in *(always available)* | — |

**Fallback chain:** `bonsai → claude → gemini → opencode → glm → quark-agent`

---

## LLM Providers

For `quark agent` and `quark super`:

| Provider | Models | Env var |
|----------|--------|---------|
| `anthropic` | Claude Opus 4, Sonnet 4, Haiku | `ANTHROPIC_API_KEY` |
| `openrouter` | 200+ — Gemini, Grok, DeepSeek, Llama, Mistral, Qwen | `OPENROUTER_API_KEY` |
| `glm` | codegeex-4, glm-4-plus, glm-4-long, glm-4-flash | `GLM_API_KEY` |

### Custom models

```bash
quark agent -m custom                         # interactive model picker
quark agent -m deepseek/deepseek-r1           # any model string directly
quark agent -m glm-4-plus:ft-your-finetune    # GLM fine-tunes work too
quark super --pick-model                       # pick model before DASA run
```

### GLM format note

All providers share an **Anthropic-format internal message history**. For `glm-4-*` models this converts to native OpenAI-compat tool calling. For `codegeex-4` and custom fine-tunes, tools are encoded as XML in the system prompt and parsed from responses — fully transparent to the agent loop.

---

## Commands

### `quark use`
Configure everything: backend, fallback, LLM provider, API key, model.

### `quark agent [task]`
Single-agent with full tool access (bash, file create/write/edit, grep, glob, ask).

```bash
quark agent "fix the auth bug"
quark agent -p openrouter -m deepseek/deepseek-r1 "refactor this module"
quark agent -p glm -m codegeex-4 "add TypeScript types"
quark agent --list-models          # pick model interactively
```

### `quark super [task]`
**Super Quark Agent** — full DASA pipeline.

```bash
quark super "build a FastAPI + MongoDB REST API"
quark super --pool-status          # view Agent Pool + Watchdog scores
quark super --pool-add             # add a custom agent to the pool
quark super --pick-model           # pick model before running
```

**DASA pipeline steps:**

```
Generator      → decomposes task, queries Agent Pool, emits Spawn Manifest
Executor       → runs each agent (scoped context, full tool access, 20 turns max)
Watchdog P1    → validates each agent: length, no stubs, required signals
Watchdog P2    → validates compound coherence across all agent outputs
Pool write-back→ updates agent scores, saves session learnings to ~/.quark/pool/
```

**10 built-in agents** auto-seeded to `~/.quark/pool/` on first run: Planner, Coder, Backend Specialist, Frontend Specialist, Tester, Reviewer, Debugger, Schema Designer, Security Auditor, Docs Writer. Add your own with `quark super --pool-add`.

### `quark start`
Open interactive session with the active backend.

### `quark run [task]`
One-shot task via active backend.

### `quark status`
Show backend availability, provider, API key status, pool location.

### `quark login` / `quark logout`
Auth for backends that need it (Bonsai).

---

## Configuration

Stored at `~/.config/quark-coder/config.json`. All keys also readable from env vars (env takes priority).

---

## Examples

```bash
# Single agent
quark agent "add pagination to the users endpoint"
quark agent -p glm -m glm-4-plus "fix the TypeScript errors"
quark agent -p openrouter -m google/gemini-2.5-pro "write integration tests"

# DASA multi-agent
quark super "user auth: register, login, JWT refresh, logout"
quark super -p openrouter -m anthropic/claude-opus-4 "add dark mode"
quark super -p glm -m glm-4-plus "optimise all database queries"

# External CLI
quark start --dir ./backend
quark run "fix the CORS error" --dir ./api
```

---

## Built by

[Mega Mind Co (MMC)](https://megamindco.com) · DASA architecture by [Tensora Labs](https://tensoralabs.com)

MIT © Hardik Tiwari
